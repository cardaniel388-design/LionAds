import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const DB_FILE = path.join(__dirname, 'data', 'db.json');
const SECRET = process.env.SESSION_SECRET || 'lionads-dev-secret-change-me';
const OPENAI_KEY = process.env.OPENAI_API_KEY || '';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-5.6-luna';
const OPENAI_BASE = (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');

async function db(){ try{return JSON.parse(await fs.readFile(DB_FILE,'utf8'));}catch{return {users:[],projects:[],offers:[],analyses:[],copies:[],creatives:[],pages:[],activity:[]};} }
async function save(data){await fs.mkdir(path.dirname(DB_FILE),{recursive:true});await fs.writeFile(DB_FILE,JSON.stringify(data,null,2));}
function id(prefix='id'){return `${prefix}_${crypto.randomBytes(8).toString('hex')}`}
function hash(s){return crypto.createHash('sha256').update(s).digest('hex')}
function cookieToken(userId){const raw=`${userId}.${crypto.createHmac('sha256',SECRET).update(userId).digest('hex')}`;return Buffer.from(raw).toString('base64url')}
function userFrom(req, data){const c=(req.headers.cookie||'').match(/lion_session=([^;]+)/)?.[1];if(!c)return null;try{const raw=Buffer.from(c,'base64url').toString();const [uid,sig]=raw.split('.');if(sig!==crypto.createHmac('sha256',SECRET).update(uid).digest('hex'))return null;return data.users.find(u=>u.id===uid)||null;}catch{return null}}
function json(res,status,obj){const body=JSON.stringify(obj);res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(body)}
async function body(req){let s='';for await(const c of req)s+=c;if(!s)return {};try{return JSON.parse(s)}catch{return {}}}
function cleanText(x=''){return String(x).replace(/\s+/g,' ').trim().slice(0,5000)}

async function ai(system, input){
  if(!OPENAI_KEY)return null;
  const r=await fetch(`${OPENAI_BASE}/responses`,{method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${OPENAI_KEY}`},body:JSON.stringify({model:OPENAI_MODEL,input:[{role:'system',content:[{type:'input_text',text:system}]},{role:'user',content:[{type:'input_text',text:input}]}]} )});
  if(!r.ok) throw new Error(`AI provider HTTP ${r.status}`);
  const j=await r.json();
  return j.output_text || j.output?.flatMap(x=>x.content||[]).map(x=>x.text||'').join('') || null;
}
function fallbackOffer(input){
  const p=cleanText(input)||'um produto digital';
  return {name:`Método ${p.slice(0,42)}`,bigIdea:`Uma forma mais estruturada de transformar ${p} em uma solução clara, específica e testável.`,promise:`Aprenda a aplicar um processo organizado para sair da ideia e chegar a uma oferta pronta para validação.`,mechanism:'Método em 4 etapas: diagnóstico → mecanismo → aplicação → validação.',audience:'Pessoas que querem resolver um problema específico com um processo simples e organizado.',benefits:['Clareza sobre o problema e a transformação','Processo passo a passo','Oferta mais fácil de comunicar','Base para testar diferentes ângulos'],bonuses:['Checklist de implementação','Banco de hooks','Modelo de página'],guarantee:'Garantia conforme a política comercial definida pelo produtor.',cta:'Quero construir minha oferta',disclaimer:'Estrutura estratégica para teste; não representa garantia de vendas.'};
}
function fallbackCopy(offer){return {headlines:[`Como transformar ${offer.name||'sua ideia'} em uma oferta clara e testável`,`O processo para sair da ideia e construir uma oferta de verdade`,`Pare de improvisar: organize sua oferta em um método simples`],hooks:['Você está tentando vender sem ter uma oferta bem estruturada?','O problema pode não ser seu produto — pode ser a forma como ele está apresentado.','Antes de criar mais um anúncio, organize a oferta.'],bullets:offer.benefits||[],cta:offer.cta||'Conhecer o método'} }
function fallbackCreative(offer){return {format:'UGC curto',angle:'problema → mecanismo → transformação',script:[`HOOK: ${fallbackCopy(offer).hooks[0]}`,`PROBLEMA: explique em uma frase o que trava o público.`,`MECANISMO: apresente o processo ${offer.mechanism}.`,`TRANSFORMAÇÃO: mostre o que muda quando o processo é aplicado.`,`CTA: ${offer.cta||'Conheça a oferta.'}`]}}
function extractPage(url){try{const u=new URL(url);return {url:u.href,domain:u.hostname,title:`Análise pública de ${u.hostname}`,signals:['URL recebida','Domínio identificado','Pronto para análise de conteúdo quando uma fonte de leitura estiver conectada.']}}catch{return null}}

async function route(req,res){
  const url=new URL(req.url,`http://${req.headers.host}`); const p=url.pathname; const method=req.method; const data=await db(); const user=userFrom(req,data);
  if(p==='/health'){return json(res,200,{ok:true,service:'lionads',aiConfigured:Boolean(OPENAI_KEY)})}
  if(p==='/api/auth/register'&&method==='POST'){const b=await body(req);const email=cleanText(b.email).toLowerCase();const password=String(b.password||'');if(!email||password.length<6)return json(res,400,{error:'Informe email e senha com pelo menos 6 caracteres.'});if(data.users.some(u=>u.email===email))return json(res,409,{error:'Email já cadastrado.'});const u={id:id('usr'),email,passwordHash:hash(password),name:cleanText(b.name)||email.split('@')[0],credits:500,createdAt:new Date().toISOString()};data.users.push(u);await save(data);res.setHeader('Set-Cookie',`lion_session=${cookieToken(u.id)}; HttpOnly; SameSite=Lax; Path=/`);return json(res,201,{user:{id:u.id,email:u.email,name:u.name,credits:u.credits}})}
  if(p==='/api/auth/login'&&method==='POST'){const b=await body(req);const u=data.users.find(x=>x.email===cleanText(b.email).toLowerCase());if(!u||u.passwordHash!==hash(String(b.password||'')))return json(res,401,{error:'Credenciais inválidas.'});res.setHeader('Set-Cookie',`lion_session=${cookieToken(u.id)}; HttpOnly; SameSite=Lax; Path=/`);return json(res,200,{user:{id:u.id,email:u.email,name:u.name,credits:u.credits}})}
  if(p==='/api/auth/logout'){res.setHeader('Set-Cookie','lion_session=; Max-Age=0; HttpOnly; SameSite=Lax; Path=/');return json(res,200,{ok:true})}
  if(p.startsWith('/api/')&&!user)return json(res,401,{error:'Faça login para continuar.'})
  if(p==='/api/me')return json(res,200,{user:{id:user.id,email:user.email,name:user.name,credits:user.credits},aiConfigured:Boolean(OPENAI_KEY)});
  if(p==='/api/projects'&&method==='GET')return json(res,200,{projects:data.projects.filter(x=>x.userId===user.id)});
  if(p==='/api/projects'&&method==='POST'){const b=await body(req);const pr={id:id('prj'),userId:user.id,name:cleanText(b.name)||'Novo projeto',description:cleanText(b.description),createdAt:new Date().toISOString()};data.projects.push(pr);data.activity.unshift({id:id('act'),userId:user.id,type:'project',text:`Projeto criado: ${pr.name}`,createdAt:pr.createdAt});await save(data);return json(res,201,{project:pr})}
  if(p==='/api/offer/generate'&&method==='POST'){const b=await body(req);const input=cleanText(b.input);if(!input)return json(res,400,{error:'Descreva o produto, público e transformação.'});let offer;try{const out=await ai('Você é o motor estratégico do LionAds. Crie uma oferta ORIGINAL. Não copie textos de referências. Responda somente JSON válido com as chaves name,bigIdea,promise,mechanism,audience,benefits,bonuses,guarantee,cta,disclaimer.',`Crie uma oferta para: ${input}`);offer=out?JSON.parse(out.replace(/^```json|```$/g,'').trim()):fallbackOffer(input)}catch{offer=fallbackOffer(input)}const o={id:id('off'),userId:user.id,input,offer,createdAt:new Date().toISOString()};data.offers.push(o);user.credits=Math.max(0,user.credits-10);data.activity.unshift({id:id('act'),userId:user.id,type:'offer',text:`Oferta criada: ${offer.name}`,createdAt:o.createdAt});await save(data);return json(res,200,{offer,credits:user.credits,source:OPENAI_KEY?'ai':'local'})}
  if(p==='/api/copy/generate'&&method==='POST'){const b=await body(req);const offer=b.offer||fallbackOffer('produto digital');let copy;try{const out=await ai('Você é um copywriter de performance do LionAds. Gere copy original, clara e sem alegações não verificadas. Responda somente JSON válido com headlines,hooks,bullets,cta.',JSON.stringify(offer));copy=out?JSON.parse(out.replace(/^```json|```$/g,'').trim()):fallbackCopy(offer)}catch{copy=fallbackCopy(offer)}user.credits=Math.max(0,user.credits-5);data.copies.push({id:id('cpy'),userId:user.id,offerId:b.offerId||null,copy,createdAt:new Date().toISOString()});await save(data);return json(res,200,{copy,credits:user.credits})}
  if(p==='/api/creative/generate'&&method==='POST'){const b=await body(req);const offer=b.offer||fallbackOffer('produto digital');let creative;try{const out=await ai('Você é estrategista de criativos de performance do LionAds. Crie roteiro original. Responda somente JSON válido com format,angle,script.',JSON.stringify(offer));creative=out?JSON.parse(out.replace(/^```json|```$/g,'').trim()):fallbackCreative(offer)}catch{creative=fallbackCreative(offer)}user.credits=Math.max(0,user.credits-5);data.creatives.push({id:id('crt'),userId:user.id,creative,createdAt:new Date().toISOString()});await save(data);return json(res,200,{creative,credits:user.credits})}
  if(p==='/api/analyze'&&method==='POST'){const b=await body(req);const ref=extractPage(cleanText(b.url));if(!ref)return json(res,400,{error:'URL inválida.'});let analysis=ref;try{const out=await ai('Analise uma referência pública fornecida pelo usuário sem inventar dados. Se não houver conteúdo da página, limite-se aos sinais fornecidos. Responda JSON com summary,strengths,attention,questions.',JSON.stringify(ref));if(out)analysis={...ref,...JSON.parse(out.replace(/^```json|```$/g,'').trim())}}catch{}data.analyses.push({id:id('ana'),userId:user.id,analysis,createdAt:new Date().toISOString()});user.credits=Math.max(0,user.credits-10);await save(data);return json(res,200,{analysis,credits:user.credits})}
  if(p==='/api/dna'&&method==='POST'){const b=await body(req);const offer=b.offer||fallbackOffer('produto digital');return json(res,200,{dna:{angle:'Problema + oportunidade',mechanism:offer.mechanism,price:'Defina após pesquisa de mercado',creative:'UGC / demonstração',cta:offer.cta,structure:['Hook','Problema','Mecanismo','Transformação','Oferta','CTA']}})}
  if(p==='/api/activity'&&method==='GET')return json(res,200,{activity:data.activity.filter(x=>x.userId===user.id).slice(0,20)});
  // static
  let file=p==='/'?'/index.html':p; const safe=path.normalize(file).replace(/^([.][.][/\\])+/, ''); const fp=path.join(__dirname,safe); if(!fp.startsWith(__dirname))return json(res,403,{error:'Forbidden'}); try{const buf=await fs.readFile(fp);const ext=path.extname(fp);const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml'};res.writeHead(200,{'content-type':types[ext]||'application/octet-stream'});res.end(buf)}catch{json(res,404,{error:'Not found'})}
}
http.createServer((req,res)=>route(req,res).catch(e=>{console.error(e);json(res,500,{error:'Erro interno.'})})).listen(PORT,()=>console.log(`LionAds running on http://localhost:${PORT}`));
