# LionAds

SaaS de inteligência e engenharia de ofertas. O projeto roda sem dependências externas obrigatórias e possui modo local; quando `OPENAI_API_KEY` é configurada, os módulos de oferta, copy, criativos e análise usam a API configurada.

## Requisitos
- Node.js 20+

## Executar
1. Copie `.env.example` para `.env`.
2. Defina `SESSION_SECRET`.
3. Opcional: defina `OPENAI_API_KEY` e `OPENAI_MODEL`.
4. Execute `npm start`.
5. Abra `http://localhost:3000`.

## Funcionalidades reais no MVP
- cadastro/login com sessão HTTP-only
- persistência local em `data/db.json`
- geração de oferta
- modelagem de oferta
- geração de copy
- geração de criativos
- análise de URL/sinais
- LionDNA
- projetos
- créditos
- camada de IA substituível
- modo local sem chave de IA

## Integrações que precisam de credenciais
A mineração de anúncios em escala, billing e publicação/hosting de páginas exigem fontes/APIs próprias. O código separa esses módulos para serem conectados sem fingir dados.

## Produção
Para produção, substituir o JSON DB por Postgres/Supabase, colocar HTTPS, secret forte, rate limiting, observabilidade e gateway de pagamentos.
