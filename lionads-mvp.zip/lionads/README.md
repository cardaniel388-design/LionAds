# LionAds
MVP front-end do LionAds — plataforma de inteligência e modelagem de ofertas.

## Rodar
Abra `index.html` diretamente no navegador ou use um servidor estático:

```bash
python3 -m http.server 8080
```

Depois acesse `http://localhost:8080`.

## Próxima etapa
Conectar autenticação, banco de dados, provedor de IA, fontes de dados de anúncios, billing e APIs externas. A interface atual separa o mock da futura lógica real.
